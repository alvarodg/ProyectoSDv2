# Include the Dropbox SDK
import dropbox

token = "kvbe4Epe2OAAAAAAAAAACFLOXRE34frCMWlvINIBHhfGehOAifIhED4gxvvVfhyU"
flow = dropbox.Dropbox(token)

f = open('working-draft.txt', 'rb')
response = flow.files_upload(f.read(), '/magnum-opus.txt')
print ('uploaded: ', response)

folder_metadata = flow.metadata('/')
print ('metadata: ', folder_metadata)

f, metadata = flow.get_file_and_metadata('/magnum-opus.txt')
out = open('magnum-opus.txt', 'wb')
out.write(f.read())
out.close()
print (metadata)


